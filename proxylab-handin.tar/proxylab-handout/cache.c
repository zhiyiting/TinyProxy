#include "cache.h"

static cache_t *cache_head;
static size_t cache_size;
static sem_t mutex, w;
static int readcnt;

/*
 * Initialize cache
 */
void cache_init()
{
	cache_head = NULL;
	cache_size = 0;
	readcnt = 0;
	Sem_init(&mutex, 0, 1);
	Sem_init(&w, 0, 1);
}

/*
 * Store cache information in a pointer
 * Add the cache pointer to cache list
 */
void cache_store(size_t filesize, char *uri, unsigned char *response)
{
	P(&w);
	cache_t *ptr = (cache_t *)Calloc(1, sizeof(*ptr));
	ptr->size = filesize;
	strcpy(ptr->uri, uri);
	ptr->content = (unsigned char*)Calloc(1, filesize);
	size_t i;
	for (i = 0; i < filesize; i++) {
		ptr->content[i] = response[i];
	}
	cache_add(ptr);
	V(&w);
}

/*
 * Add cache into a linked list
 */
void cache_add(cache_t *ptr)
{
	if (cache_size + ptr->size <= MAX_CACHE_SIZE) {
		if (cache_head != NULL) {
			ptr->next = cache_head;
		}
		cache_head = ptr;
		cache_size += ptr->size;
	}
	else {
		/* delete the last cache item */
		cache_delete();
		/* Continue to add this item */
		cache_add(ptr);
	}
}

/*
 * Delete a cache item in the list
 */
void cache_delete()
{
	cache_t *ptr = cache_head;
	cache_t *prev = NULL;
	while (ptr != NULL && ptr->next != NULL) {
		prev = ptr;
		ptr = ptr->next;
	}
	if (prev != NULL) {
		prev->next = NULL;
	}
	else {
		cache_head = NULL;
	}
	cache_size -= ptr->size;
	Free(ptr);
}

/*
 * Find if the item is in the cache
 */
cache_t *cache_find(char *uri)
{
	/* Reader lock */
	P(&mutex);
	readcnt++;
	if (readcnt == 1)
		P(&w);
	V(&mutex);
	cache_t *ptr = cache_head;
	cache_t *result = NULL;
	/* Linearly look through the list */
	while (ptr != NULL) {
		if (!strcmp(uri, ptr->uri)) {
			result = ptr;
			break;
		}
		ptr = ptr->next;
	}
	P(&mutex);
	readcnt--;
	if (readcnt == 0)
		V(&w);
	V(&mutex);
	return result;
}